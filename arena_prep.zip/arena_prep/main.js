// Slide navigation and interaction functionality

let currentSlide = 1;
let totalSlides = 8; // Will be updated when slides are loaded

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Wait for slides to be loaded before initializing
    setTimeout(() => {
        totalSlides = document.querySelectorAll('.slide').length;
        updateSlideCounter();
        updateNavigationButtons();
    }, 100);
});

// Navigate to next slide
function nextSlide() {
    const slides = document.querySelectorAll('.slide');
    if (currentSlide < slides.length) {
        slides[currentSlide - 1].classList.remove('active');
        currentSlide++;
        slides[currentSlide - 1].classList.add('active');
        updateSlideCounter();
        updateNavigationButtons();
        scrollToTop();
    }
}

// Navigate to previous slide
function previousSlide() {
    const slides = document.querySelectorAll('.slide');
    if (currentSlide > 1) {
        slides[currentSlide - 1].classList.remove('active');
        currentSlide--;
        slides[currentSlide - 1].classList.add('active');
        updateSlideCounter();
        updateNavigationButtons();
        scrollToTop();
    }
}

// Update slide counter display
function updateSlideCounter() {
    const slides = document.querySelectorAll('.slide');
    totalSlides = slides.length;
    const counter = document.querySelector('.slide-counter');
    if (counter) {
        counter.textContent = `${currentSlide} / ${totalSlides}`;
    }
}

// Update navigation button states
function updateNavigationButtons() {
    const prevButton = document.getElementById('prev-button');
    const nextButton = document.getElementById('next-button');
    
    if (prevButton) prevButton.disabled = currentSlide === 1;
    if (nextButton) nextButton.disabled = currentSlide === totalSlides;
}

// Toggle deep dive sections - updated for new button format
function toggleDeepDive(button) {
    const slide = button.closest('.slide');
    const deepDiveSection = slide.querySelector('.deep-dive');
    
    if (deepDiveSection) {
        if (deepDiveSection.style.display === 'none' || !deepDiveSection.style.display) {
            deepDiveSection.style.display = 'block';
            button.textContent = 'Hide Details ↑';
        } else {
            deepDiveSection.style.display = 'none';
            button.textContent = 'Deep Dive →';
        }
    }
}

// Legacy deep dive function for older slides
function toggleDeepDiveById(sectionId) {
    const section = document.getElementById(sectionId);
    const button = event.target;
    
    if (section.classList.contains('active')) {
        section.classList.remove('active');
        button.textContent = button.textContent.replace('↑', '↓');
    } else {
        section.classList.add('active');
        button.textContent = button.textContent.replace('↓', '↑');
    }
}

// Scroll to top of slide
function scrollToTop() {
    const activeSlide = document.querySelector('.slide.active');
    if (activeSlide) {
        activeSlide.scrollTop = 0;
    }
    // Also scroll the main container
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Keyboard navigation
document.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        nextSlide();
    } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        previousSlide();
    } else if (e.key === 'Escape') {
        // Close all deep dives
        document.querySelectorAll('.deep-dive').forEach(section => {
            section.style.display = 'none';
        });
        document.querySelectorAll('.deep-dive-button').forEach(button => {
            button.textContent = 'Deep Dive →';
        });
    }
});

// Touch navigation for tablets
let touchStartX = null;

document.addEventListener('touchstart', function(e) {
    touchStartX = e.touches[0].clientX;
});

document.addEventListener('touchend', function(e) {
    if (!touchStartX) return;
    
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;
    
    if (Math.abs(diff) > 50) { // Minimum swipe distance
        if (diff > 0) {
            nextSlide(); // Swipe left
        } else {
            previousSlide(); // Swipe right
        }
    }
    
    touchStartX = null;
}); 